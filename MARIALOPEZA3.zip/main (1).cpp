/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main() 
{
    string NOMBRE ="";
    string A_paterno ="";
    string A_materno ="";
    string Vocal ="";
    string DIA ="";
    string MES ="";
    string YEAR ="";
    string RFC ="";
    
    cout<<"CALCULO DE RFC"<<endl;
    cout<<"utiliza mayusculas"<<endl;
    cout<<"INTRODUCE TU NOMBRE ";
    cin >> NOMBRE;
    cout<<"INTRODUCE TU APELLIDO PATERNO ";
    cin>>A_paterno;
    cout<<"INTRODUCE TU APELLIDO MATERNO ";
    cin>>A_materno;
    cout<<"FECHA DE NACIMIENTO (solo numeros DD/MM/AAAA)"<<endl;
    cout<<" DIA: ";
    cin>>DIA;
    cout<<" MES: ";
    cin>>MES;
    cout<<" AÑO: ";
    cin>> YEAR;
    cout<<"tu nombre es: "<<NOMBRE<< " "<<A_paterno<< " "<<A_materno<< endl;
    cout<<"tu nombre es: "<<DIA<< " "<<MES<< " "<<YEAR<< endl;
    RFC=A_paterno.substr(0,2);
    
    for (int i=1; i<A_paterno.length();++i){
        char letra = A_paterno[i];
        if (letra=='A'||letra =='E'||letra =='I'||letra == 'O'||letra =='U'){
            Vocal+=letra;
            break;
        }
    }
    RFC=RFC+Vocal;
     
     RFC=RFC+A_materno.substr(0,1);
     
     RFC=RFC+NOMBRE.substr(0,1);
     
     RFC=RFC+YEAR.substr(2,2);
  
     RFC=RFC+MES;
     
     RFC=RFC+DIA;
     cout<<"TU RFC SIN HOMOCLAVE ES:" <<RFC<<endl;

    return 0;
}
